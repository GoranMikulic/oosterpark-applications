module.exports = {
  kismetServer: {
    address: "213.124.216.186",
    //for rpi: address: "127.0.0.1",
    port: 2501
  },
  webServer: {
    port: 8080
  }
}
