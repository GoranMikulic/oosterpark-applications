(function() {

  angular.module('dataAnalizingApp', ['btford.socket-io']);

})();
